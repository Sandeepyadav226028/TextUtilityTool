const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const History = require("../models/History");
const User = require("../models/User");

const JWT_SECRET = process.env.JWT_SECRET || "secret123"; // same as in auth.js

// Middleware to verify token
// Middleware to verify token
function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) return res.status(401).json({ error: "No token provided" });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: "Invalid token" });
    console.log("Decoded JWT:", user);  // ← debug
    req.user = user;
    next();
  });
}


// POST /api/history - Save user text
router.post("/", authenticateToken, async (req, res) => {
  try {
    const newHistory = new History({
      userId: req.user.id,
      content: req.body.content,
    });

    await newHistory.save();
    res.json({ message: "History saved" });
  } catch (err) {
    console.error("Failed to save history:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// GET /api/history - Fetch user's text history
router.get("/", authenticateToken, async (req, res) => {
  try {
    const history = await History.find({ userId: req.user.id }).sort({ createdAt: -1 });
    res.json(history);
  } catch (err) {
    console.error("Failed to fetch history:", err);
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
