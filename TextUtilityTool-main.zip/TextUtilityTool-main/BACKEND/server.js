const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

// Routes
const authRoutes = require("./routes/auth");
const historyRoutes = require("./routes/history");

const app = express();
const PORT = 3000;

// Middlewares
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/history", historyRoutes);

// Connect to MongoDB
mongoose
  .connect("mongodb+srv://sy9670208220:Daoist_Kalyug@textutilityproject.fjzsqup.mongodb.net/textutility?retryWrites=true&w=majority&appName=TextUtilityProject")
  .then(() => {
    console.log("MongoDB connected");
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err);
  });
